module.exports = {
    'Image': require('./image'),
    'Comment': require('./comment')
};
