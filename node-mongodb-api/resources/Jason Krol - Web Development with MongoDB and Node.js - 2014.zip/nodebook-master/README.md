# Web Development with MongoDB and Node.js

**Buy Online: [Amazon.com](www.amazon.com/Development-MongoDB-Node-js-Jason-Krol/dp/1783987308/) | [PacktPub.com](https://www.packtpub.com/web-development/web-development-mongodb-and-nodejs)**

Thanks for reading my book!  This is the main repository for all of the code used and discussed throughout the entire book.  Each chapter is broken down into its own folder with iterative changes in each.  The end product is the imgPloadr folder that contains the entire working application.

**For more information about the book:**

[http://kroltech.com/2014/10/my-new-book-web-development-with-mongodb-and-node-js/](http://kroltech.com/2014/10/my-new-book-web-development-with-mongodb-and-node-js/)
