/* jshint node: true, camelcase: false */
'use strict';

module.exports = {
    'Image': require('./image'),
    'Comment': require('./comment')
};
